from django.conf import settings

from apps.core.negozi import negozio_label, normalize_negozio_code
from apps.core.programma import get_configurazione_programma


def current_negozio(request):
    code = normalize_negozio_code(request.session.get("negozio"))
    return {
        "current_negozio_code": code,
        "current_negozio_label": negozio_label(code),
    }


def programma_settings(request):
    # Evita query inutili su login/logout (pagine senza layout app).
    path = getattr(request, "path", "") or ""
    if path.startswith(("/login/", "/logout/")):
        return {
            "webcam_tasto_scatto": "",
            "webcam_tasto_usa_foto": "",
            "webcam_tasto_nuovo_scatto": "",
            "comunicazioni_mostra_allegato": True,
            "comunicazioni_formato_data": "",
            "cie_reader_on_server": getattr(settings, "CIE_READER_ON_SERVER", True),
        }

    cfg = get_configurazione_programma()
    return {
        "webcam_tasto_scatto": cfg.webcam_tasto_scatto or "",
        "webcam_tasto_usa_foto": cfg.webcam_tasto_usa_foto or "",
        "webcam_tasto_nuovo_scatto": cfg.webcam_tasto_nuovo_scatto or "",
        "comunicazioni_mostra_allegato": cfg.comunicazioni_mostra_allegato,
        "comunicazioni_formato_data": cfg.comunicazioni_formato_data,
        "cie_reader_on_server": getattr(settings, "CIE_READER_ON_SERVER", True),
    }
