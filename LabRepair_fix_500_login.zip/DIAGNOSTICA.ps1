param([string]$Dest = "")
$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Dest) {
  if (Test-Path (Join-Path $here "manage.py")) { $Dest = $here }
  else { Write-Host "Uso: .\DIAGNOSTICA.ps1 -Dest D:\percorso\LabRepair"; exit 1 }
}
Set-Location $Dest
$py = Join-Path $Dest ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = "python" }

Write-Host "=== LabRepair diagnostica ==="
Write-Host "Cartella: $Dest"
Write-Host "Python: $py"
Write-Host ""

& $py -c @"
import os, sys, traceback
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
print('1) django.setup ...')
try:
    import django
    django.setup()
    print('   OK')
except Exception:
    traceback.print_exc()
    sys.exit(1)

print('2) import login ...')
try:
    from apps.accounts.views import LoginView
    from apps.accounts.forms import LoginForm
    print('   OK')
except Exception:
    traceback.print_exc()
    sys.exit(1)

print('3) migration 0039 senza_spesa ...')
try:
    from django.core.management import call_command
    from io import StringIO
    s = StringIO()
    call_command('showmigrations', 'pratiche', stdout=s)
    lines = [l for l in s.getvalue().splitlines() if '0039' in l]
    print('  ', lines[0] if lines else '0039 NON TROVATA')
except Exception:
    traceback.print_exc()

print('4) GET /login/?app=1 ...')
try:
    from django.test import Client
    from django.conf import settings
    host = (settings.ALLOWED_HOSTS or ['127.0.0.1'])[0]
    if host == '*':
        host = '127.0.0.1'
    c = Client(HTTP_HOST=host)
    r = c.get('/login/?app=1')
    print('   STATUS', r.status_code)
    if r.status_code >= 400:
        print(r.content[:2500].decode('utf-8', 'replace'))
except Exception:
    traceback.print_exc()
    sys.exit(1)

print('')
print('Diagnostica completata.')
"@
