function getCurrentTheme() {
    return document.documentElement.getAttribute("data-bs-theme") || "light";
}

function applyTheme(theme) {
    const normalizedTheme = theme === "dark" ? "dark" : "light";
    const toggleButton = document.querySelector("[data-theme-toggle]");
    const toggleIcon = document.querySelector("[data-theme-toggle-icon]");
    const label = normalizedTheme === "dark" ? "Attiva tema chiaro" : "Attiva tema scuro";

    document.documentElement.setAttribute("data-bs-theme", normalizedTheme);
    localStorage.setItem("labrepair-theme", normalizedTheme);
    localStorage.setItem("securtek-theme", normalizedTheme);

    if (toggleButton) {
        toggleButton.setAttribute("aria-label", label);
        toggleButton.setAttribute("title", label);
    }

    if (toggleIcon) {
        toggleIcon.classList.toggle("ti-moon", normalizedTheme !== "dark");
        toggleIcon.classList.toggle("ti-sun", normalizedTheme === "dark");
    }
}

function padDatePart(value) {
    return String(value).padStart(2, "0");
}

function todayIsoDate() {
    const now = new Date();
    return `${now.getFullYear()}-${padDatePart(now.getMonth() + 1)}-${padDatePart(now.getDate())}`;
}

function nowIsoDateTimeLocal() {
    const now = new Date();
    return `${now.getFullYear()}-${padDatePart(now.getMonth() + 1)}-${padDatePart(now.getDate())}T${padDatePart(now.getHours())}:${padDatePart(now.getMinutes())}`;
}

function initCurrentYearDateFields() {
    document.querySelectorAll('input[type="date"][data-current-year="true"]').forEach(function (field) {
        field.addEventListener("focus", function () {
            if (!field.value) {
                field.value = todayIsoDate();
            }
        });
    });

    document.querySelectorAll('input[type="datetime-local"][data-current-year="true"]').forEach(function (field) {
        field.addEventListener("focus", function () {
            if (!field.value) {
                field.value = nowIsoDateTimeLocal();
            }
        });
    });
}

function initCollapsibleSections() {
    function setSectionCollapsed(button, section, collapsed, persist) {
        section.hidden = collapsed;
        button.classList.toggle("is-collapsed", collapsed);
        button.setAttribute("aria-expanded", collapsed ? "false" : "true");
        button.title = collapsed ? "Espandi sezione" : "Comprimi sezione";

        if (persist && button.dataset.storageKey) {
            localStorage.setItem(button.dataset.storageKey, collapsed ? "1" : "0");
        }
    }

    document.querySelectorAll(".st-collapse-toggle").forEach(function (button) {
        if (button.dataset.collapseReady === "1") {
            return;
        }

        const section = document.getElementById(button.dataset.collapseTarget);
        if (!section) {
            return;
        }

        button.dataset.storageKey = [
            "labrepair",
            "collapse",
            window.location.pathname,
            button.dataset.collapseKey || button.dataset.collapseTarget,
        ].join(":");

        button.dataset.collapseReady = "1";
        setSectionCollapsed(
            button,
            section,
            localStorage.getItem(button.dataset.storageKey) === "1",
            false
        );

        button.addEventListener("click", function () {
            setSectionCollapsed(button, section, !section.hidden, true);
        });
    });

    if (window.location.hash === "#comunicazioni") {
        const panel = document.getElementById("practice-communications-panel");
        const toggle = document.querySelector(
            '[data-collapse-target="practice-communications-panel"], [data-collapse-target="practice-communications-section"]'
        );
        if (panel && toggle) {
            setSectionCollapsed(toggle, panel, false, true);
            document.getElementById("comunicazioni")?.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    }
}

function initComunicazioneDeleteConfirm() {
    document.querySelectorAll("form[data-comunicazione-delete]").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault();

            const ask = window.LabRepairConfirm
                ? window.LabRepairConfirm.ask({
                      title: "Elimina comunicazione",
                      message: "Vuoi eliminare questa comunicazione?",
                      confirmLabel: "Elimina",
                      cancelLabel: "Annulla",
                      confirmClass: "btn btn-danger",
                      variant: "danger",
                  })
                : Promise.resolve(window.confirm("Vuoi eliminare questa comunicazione?"));

            ask.then(function (confirmed) {
                if (confirmed) {
                    form.submit();
                }
            });
        });
    });
}

function initPraticaDeleteConfirm() {
    const modalElement = document.getElementById("deletePraticaModal");
    const form = document.getElementById("deletePraticaForm");
    const nameElement = document.getElementById("deletePraticaName");
    const cancelButton = modalElement
        ? modalElement.querySelector(".js-delete-pratica-cancel")
        : null;

    if (!modalElement || !form || !nameElement || !cancelButton) {
        return;
    }

    function closeModal() {
        modalElement.hidden = true;
        document.body.classList.remove("st-confirm-open");
        form.removeAttribute("action");
    }

    function openModal(action, name) {
        form.action = action || "";
        nameElement.textContent = name || "Riparazione selezionata";
        modalElement.hidden = false;
        document.body.classList.add("st-confirm-open");
    }

    document.querySelectorAll(".js-delete-pratica").forEach(function (button) {
        button.addEventListener("click", function () {
            openModal(button.dataset.deleteAction, button.dataset.deleteName);
        });
    });

    cancelButton.addEventListener("click", closeModal);

    modalElement.addEventListener("click", function (event) {
        if (event.target === modalElement) {
            closeModal();
        }
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape" && !modalElement.hidden) {
            closeModal();
        }
    });
}

function disableBrowserFieldSuggestions(root) {
    const scope = root && root.querySelectorAll ? root : document;
    const guardedTypes = {
        text: true,
        search: true,
        email: true,
        tel: true,
        url: true,
        number: true,
        password: true,
        date: true,
        "datetime-local": true,
        time: true,
        month: true,
        week: true,
    };

    scope.querySelectorAll("form").forEach(function (form) {
        form.setAttribute("autocomplete", "off");
    });

    scope.querySelectorAll("input, textarea, select").forEach(function (field) {
        if (field.type === "hidden") {
            return;
        }

        // Valore non standard: Chrome ignora spesso solo "off".
        field.setAttribute("autocomplete", "labrepair-off");
        field.setAttribute("autocorrect", "off");
        field.setAttribute("autocapitalize", "off");

        if (field.hasAttribute("list")) {
            field.removeAttribute("list");
        }

        // Blocca l'autofill all'apertura pagina (nome/cognome/indirizzo/email).
        if (
            (field.tagName === "TEXTAREA" || guardedTypes[field.type] || field.type === "") &&
            field.dataset.autofillGuard !== "1"
        ) {
            field.dataset.autofillGuard = "1";
            field.setAttribute("readonly", "readonly");
            const unlock = function () {
                field.removeAttribute("readonly");
            };
            field.addEventListener("focus", unlock, { once: true });
            field.addEventListener("mousedown", unlock, { once: true });
            field.addEventListener("touchstart", unlock, { once: true });
        }
    });

    scope.querySelectorAll("datalist").forEach(function (list) {
        list.remove();
    });
}

document.addEventListener("DOMContentLoaded", function () {
    initCurrentYearDateFields();
    initCollapsibleSections();
    initComunicazioneDeleteConfirm();
    initPraticaDeleteConfirm();
    disableBrowserFieldSuggestions(document);

    document.body.addEventListener("htmx:afterSwap", function (event) {
        disableBrowserFieldSuggestions(event.target || document);
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.querySelector("[data-sidebar-toggle]");
    const backdrop = document.querySelector("[data-sidebar-backdrop]");

    function closeSidebar() {
        document.body.classList.remove("st-sidebar-open");
    }

    if (toggleButton) {
        toggleButton.addEventListener("click", function () {
            document.body.classList.toggle("st-sidebar-open");
        });
    }

    if (backdrop) {
        backdrop.addEventListener("click", closeSidebar);
    }

    document.querySelectorAll(".st-sidebar .st-nav-link").forEach(function (link) {
        link.addEventListener("click", function () {
            if (window.matchMedia("(max-width: 991.98px)").matches) {
                closeSidebar();
            }
        });
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.querySelector("[data-theme-toggle]");

    applyTheme(getCurrentTheme());

    if (!toggleButton) {
        return;
    }

    toggleButton.addEventListener("click", function () {
        applyTheme(getCurrentTheme() === "dark" ? "light" : "dark");
    });
});
