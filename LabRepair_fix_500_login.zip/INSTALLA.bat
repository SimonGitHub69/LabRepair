@echo off
cd /d "%~dp0"
if "%~1"=="" (powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA.ps1") else (powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA.ps1" -Dest "%~1")
pause
