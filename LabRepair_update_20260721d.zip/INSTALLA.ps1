# LabRepair - installa aggiornamento SOVRASCRIVENDO i file esistenti
# Uso: estrai lo zip in una cartella temporanea, poi esegui:
#   powershell -ExecutionPolicy Bypass -File .\INSTALlA.ps1 -Dest "C:\percorso\LabRepair"
# Oppure, se hai estratto DENTRO la root LabRepair, esegui senza -Dest.

param(
    [string]$Dest = ""
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not $Dest) {
    # Se lo script e' nella root LabRepair (c'e' manage.py), usa quella
    if (Test-Path (Join-Path $here "manage.py")) {
        $Dest = $here
    } else {
        Write-Host "Indica la cartella LabRepair sul server, es.:"
        Write-Host '  .\INSTALLA.ps1 -Dest "D:\LabRepair"'
        exit 1
    }
}

if (-not (Test-Path (Join-Path $Dest "manage.py"))) {
    throw "Destinazione non valida (manca manage.py): $Dest"
}

Write-Host "Origine:  $here"
Write-Host "Destinazione: $Dest"
Write-Host "Copia con SOVRASCRITTURA..."

$copied = 0
Get-ChildItem $here -Recurse -File | Where-Object {
    $_.Name -notin @("INSTALLA.ps1","INSTALLA.bat","LEGGIMI.txt")
} | ForEach-Object {
    $rel = $_.FullName.Substring($here.Length).TrimStart("\","/")
    $target = Join-Path $Dest $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
    Copy-Item $_.FullName $target -Force
    Write-Host "  OK $rel"
    $copied++
}

Write-Host ""
Write-Host "File sovrascritti: $copied"
Write-Host "Esegui ora collectstatic e riavvia Waitress:"
Write-Host "  cd `"$Dest`""
Write-Host "  .\.venv\Scripts\python.exe manage.py collectstatic --noinput"
Write-Host "  (poi riavvia il servizio / Waitress)"
