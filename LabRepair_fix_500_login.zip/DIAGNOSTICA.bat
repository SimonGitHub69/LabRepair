@echo off
cd /d "%~dp0"
if "%~1"=="" (powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0DIAGNOSTICA.ps1") else (powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0DIAGNOSTICA.ps1" -Dest "%~1")
pause
