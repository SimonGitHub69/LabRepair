from django import forms
from django.contrib.auth.forms import AuthenticationForm

from apps.core.negozi import NEGOZI


class LoginForm(AuthenticationForm):
    negozio = forms.ChoiceField(
        label="Negozio",
        choices=NEGOZI,
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].widget.attrs.update(
            {"class": "form-control", "autocomplete": "off", "autofocus": True}
        )
        self.fields["password"].widget.attrs.update(
            {"class": "form-control", "autocomplete": "off"}
        )
