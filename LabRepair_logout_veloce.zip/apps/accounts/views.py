from django.contrib.auth import login, logout
from django.contrib.auth.views import LoginView as AuthLoginView
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views import View

from apps.accounts.forms import LoginForm
from apps.core.negozi import normalize_negozio_code


class LoginView(AuthLoginView):
    template_name = "accounts/login.html"
    authentication_form = LoginForm
    redirect_authenticated_user = True

    def form_valid(self, form):
        response = super().form_valid(form)
        negozio = normalize_negozio_code(form.cleaned_data.get("negozio"))
        if negozio:
            self.request.session["negozio"] = negozio
        return response

    def get_success_url(self):
        return self.get_redirect_url() or reverse_lazy("dashboard:index")


class LogoutView(View):
    def post(self, request, *args, **kwargs):
        request.session.pop("negozio", None)
        logout(request)
        # redirect 302 immediato alla login (niente template pesante in questa view)
        response = redirect("accounts:login")
        response["Cache-Control"] = "no-store"
        return response

    def get(self, request, *args, **kwargs):
        return self.post(request, *args, **kwargs)
