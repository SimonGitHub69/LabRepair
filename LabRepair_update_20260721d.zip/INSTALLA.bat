@echo off
setlocal
REM Doppio click: se sei nella root LabRepair con manage.py, installa qui.
REM Altrimenti passa il percorso: INSTALLA.bat "D:\LabRepair"

cd /d "%~dp0"
if "%~1"=="" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA.ps1"
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA.ps1" -Dest "%~1"
)
pause
