param([string]$Dest = "")
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Dest) {
  if (Test-Path (Join-Path $here "manage.py")) { $Dest = $here }
  else { Write-Host 'Uso: .\INSTALLA.ps1 -Dest "D:\percorso\LabRepair"'; exit 1 }
}
if (-not (Test-Path (Join-Path $Dest "manage.py"))) { throw "Dest non valida: $Dest" }

Write-Host "Copia file (sovrascrittura) in $Dest"
Get-ChildItem $here -Recurse -File | Where-Object {
  $_.Name -notin @("INSTALLA.ps1","INSTALLA.bat","DIAGNOSTICA.ps1","DIAGNOSTICA.bat","LEGGIMI.txt")
} | ForEach-Object {
  $rel = $_.FullName.Substring($here.Length).TrimStart("\","/")
  $target = Join-Path $Dest $rel
  New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
  Copy-Item $_.FullName $target -Force
  Write-Host "  OK $rel"
}

$py = Join-Path $Dest ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = "python" }
Write-Host ""
Write-Host "Migrazioni..."
& $py (Join-Path $Dest "manage.py") migrate --noinput
Write-Host "collectstatic..."
& $py (Join-Path $Dest "manage.py") collectstatic --noinput
Write-Host ""
Write-Host "FATTO. Riavvia Waitress, poi apri /login/"
Write-Host "Se ancora 500: esegui DIAGNOSTICA.bat e leggi l'output."
