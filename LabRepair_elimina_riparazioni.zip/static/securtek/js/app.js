function getCurrentTheme() {
    return document.documentElement.getAttribute("data-bs-theme") || "light";
}

function applyTheme(theme) {
    const normalizedTheme = theme === "dark" ? "dark" : "light";
    const toggleButton = document.querySelector("[data-theme-toggle]");
    const toggleIcon = document.querySelector("[data-theme-toggle-icon]");
    const label = normalizedTheme === "dark" ? "Attiva tema chiaro" : "Attiva tema scuro";

    document.documentElement.setAttribute("data-bs-theme", normalizedTheme);
    localStorage.setItem("labrepair-theme", normalizedTheme);
    localStorage.setItem("securtek-theme", normalizedTheme);

    if (toggleButton) {
        toggleButton.setAttribute("aria-label", label);
        toggleButton.setAttribute("title", label);
    }

    if (toggleIcon) {
        toggleIcon.classList.toggle("ti-moon", normalizedTheme !== "dark");
        toggleIcon.classList.toggle("ti-sun", normalizedTheme === "dark");
    }
}

function padDatePart(value) {
    return String(value).padStart(2, "0");
}

function todayIsoDate() {
    const now = new Date();
    return `${now.getFullYear()}-${padDatePart(now.getMonth() + 1)}-${padDatePart(now.getDate())}`;
}

function nowIsoDateTimeLocal() {
    const now = new Date();
    return `${now.getFullYear()}-${padDatePart(now.getMonth() + 1)}-${padDatePart(now.getDate())}T${padDatePart(now.getHours())}:${padDatePart(now.getMinutes())}`;
}

function initCurrentYearDateFields() {
    document.querySelectorAll('input[type="date"][data-current-year="true"]').forEach(function (field) {
        field.addEventListener("focus", function () {
            if (!field.value) {
                field.value = todayIsoDate();
            }
        });
    });

    document.querySelectorAll('input[type="datetime-local"][data-current-year="true"]').forEach(function (field) {
        field.addEventListener("focus", function () {
            if (!field.value) {
                field.value = nowIsoDateTimeLocal();
            }
        });
    });
}

function initCollapsibleSections() {
    function setSectionCollapsed(button, section, collapsed, persist) {
        section.hidden = collapsed;
        button.classList.toggle("is-collapsed", collapsed);
        button.setAttribute("aria-expanded", collapsed ? "false" : "true");
        button.title = collapsed ? "Espandi sezione" : "Comprimi sezione";

        if (persist && button.dataset.storageKey) {
            localStorage.setItem(button.dataset.storageKey, collapsed ? "1" : "0");
        }
    }

    document.querySelectorAll(".st-collapse-toggle").forEach(function (button) {
        if (button.dataset.collapseReady === "1") {
            return;
        }

        const section = document.getElementById(button.dataset.collapseTarget);
        if (!section) {
            return;
        }

        button.dataset.storageKey = [
            "labrepair",
            "collapse",
            window.location.pathname,
            button.dataset.collapseKey || button.dataset.collapseTarget,
        ].join(":");

        button.dataset.collapseReady = "1";
        setSectionCollapsed(
            button,
            section,
            localStorage.getItem(button.dataset.storageKey) === "1",
            false
        );

        button.addEventListener("click", function () {
            setSectionCollapsed(button, section, !section.hidden, true);
        });
    });

    if (window.location.hash === "#comunicazioni") {
        const panel = document.getElementById("practice-communications-panel");
        const toggle = document.querySelector(
            '[data-collapse-target="practice-communications-panel"], [data-collapse-target="practice-communications-section"]'
        );
        if (panel && toggle) {
            setSectionCollapsed(toggle, panel, false, true);
            document.getElementById("comunicazioni")?.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    }
}

function initComunicazioneDeleteConfirm() {
    document.querySelectorAll("form[data-comunicazione-delete]").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault();

            const ask = window.LabRepairConfirm
                ? window.LabRepairConfirm.ask({
                      title: "Elimina comunicazione",
                      message: "Vuoi eliminare questa comunicazione?",
                      confirmLabel: "Elimina",
                      cancelLabel: "Annulla",
                      confirmClass: "btn btn-danger",
                      variant: "danger",
                  })
                : Promise.resolve(window.confirm("Vuoi eliminare questa comunicazione?"));

            ask.then(function (confirmed) {
                if (confirmed) {
                    form.submit();
                }
            });
        });
    });
}

function initPraticaDeleteConfirm() {
    document.querySelectorAll("form[data-pratica-delete]").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault();

            const code = form.dataset.praticaCode || "questa riparazione";
            const message =
                "Vuoi eliminare la riparazione <strong>" +
                code +
                "</strong>?<br>Non sarà più visibile nell&apos;elenco.";

            const ask = window.LabRepairConfirm
                ? window.LabRepairConfirm.ask({
                      title: "Elimina riparazione",
                      message: message,
                      confirmLabel: "Elimina",
                      cancelLabel: "Annulla",
                      confirmClass: "btn btn-danger",
                      variant: "danger",
                  })
                : Promise.resolve(
                      window.confirm("Vuoi eliminare la riparazione " + code + "?")
                  );

            ask.then(function (confirmed) {
                if (confirmed) {
                    form.submit();
                }
            });
        });
    });
}

function disableBrowserFieldSuggestions(root) {
    const scope = root && root.querySelectorAll ? root : document;
    const guardedTypes = {
        text: true,
        search: true,
        email: true,
        tel: true,
        url: true,
        number: true,
        password: true,
        date: true,
        "datetime-local": true,
        time: true,
        month: true,
        week: true,
    };

    scope.querySelectorAll("form").forEach(function (form) {
        form.setAttribute("autocomplete", "off");
    });

    scope.querySelectorAll("input, textarea, select").forEach(function (field) {
        if (field.type === "hidden") {
            return;
        }

        // Valore non standard: Chrome ignora spesso solo "off".
        field.setAttribute("autocomplete", "labrepair-off");
        field.setAttribute("autocorrect", "off");
        field.setAttribute("autocapitalize", "off");

        if (field.hasAttribute("list")) {
            field.removeAttribute("list");
        }

        // Blocca l'autofill all'apertura pagina (nome/cognome/indirizzo/email).
        if (
            (field.tagName === "TEXTAREA" || guardedTypes[field.type] || field.type === "") &&
            field.dataset.autofillGuard !== "1"
        ) {
            field.dataset.autofillGuard = "1";
            field.setAttribute("readonly", "readonly");
            const unlock = function () {
                field.removeAttribute("readonly");
            };
            field.addEventListener("focus", unlock, { once: true });
            field.addEventListener("mousedown", unlock, { once: true });
            field.addEventListener("touchstart", unlock, { once: true });
        }
    });

    scope.querySelectorAll("datalist").forEach(function (list) {
        list.remove();
    });
}

document.addEventListener("DOMContentLoaded", function () {
    initCurrentYearDateFields();
    initCollapsibleSections();
    initComunicazioneDeleteConfirm();
    initPraticaDeleteConfirm();
    disableBrowserFieldSuggestions(document);

    document.body.addEventListener("htmx:afterSwap", function (event) {
        disableBrowserFieldSuggestions(event.target || document);
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.querySelector("[data-sidebar-toggle]");
    const backdrop = document.querySelector("[data-sidebar-backdrop]");

    function closeSidebar() {
        document.body.classList.remove("st-sidebar-open");
    }

    if (toggleButton) {
        toggleButton.addEventListener("click", function () {
            document.body.classList.toggle("st-sidebar-open");
        });
    }

    if (backdrop) {
        backdrop.addEventListener("click", closeSidebar);
    }

    document.querySelectorAll(".st-sidebar .st-nav-link").forEach(function (link) {
        link.addEventListener("click", function () {
            if (window.matchMedia("(max-width: 991.98px)").matches) {
                closeSidebar();
            }
        });
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.querySelector("[data-theme-toggle]");

    applyTheme(getCurrentTheme());

    if (!toggleButton) {
        return;
    }

    toggleButton.addEventListener("click", function () {
        applyTheme(getCurrentTheme() === "dark" ? "light" : "dark");
    });
});
